<!-- registration number: 1906423 -->
# WebDevClass_GamesCatalogue
Website for a class. PHP, SQL +web technologies
