-- registration number: 1906423
USE assigment2020;

--not being used **

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/8930/header.jpg?t=1579731804"
where id = 1;

update games
set image="https://www.hrkgame.com/media/games/.thumbnails/header_hv4Gcap.jpg/header_hv4Gcap-460x215.jpg"
where id = 2;

update games
set image="https://bnetcmsus-a.akamaihd.net/cms/template_resource/MFOHLV6RD1VK1541005871536.jpg"
where id = 3;

update games
set image="https://hb.imgix.net/43d2b953aca4d67b18929a09c4b97313758ee779.jpg?auto=compress,format&fit=crop&h=353&w=616&s=7c29152cd0e6a05fbdf549c1303aefec"
where id = 4;

update games
set image="https://vignette.wikia.nocookie.net/shadowrun/images/b/ba/Dragonfall_directorscut_poster.jpg/revision/latest?cb=20180316130658&path-prefix=en"
where id = 5;

update games
set image="https://hb.imgix.net/00797f64c64a677883a9a3ef8a46ab21d7d67020.jpeg?auto=compress,format&fit=crop&h=353&w=616&s=6dbb376bb30e6953659876cb4cb6b368"
where id = 6;

update games
set image="https://images.gog-statics.com/0d4244c2fd3525dca5278a1bfa6e6a50608d690ec473e4597f53b76c8211aed4_product_card_v2_mobile_slider_639.jpg"
where id = 7;

update games
set image="https://i0.wp.com/play3r.net/wp-content/uploads/2015/04/Rimworld_cover.jpg?fit=745%2C485&ssl=1"
where id = 8;

update games
set image="https://www.idgcdn.com.au/article/images/740x500/dimg/rainbow-six.jpg"
where id = 9;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/227300/header.jpg?t=1580390416"
where id = 10;

update games
set image="https://gpstatic.com/acache/37/28/1/uk/t620x300.jpg"
where id = 11;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/24010/header.jpg?t=1582815384"
where id = 12;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/108600/header.jpg?t=1575377037"
where id = 13;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/234650/header.jpg?t=1577749569"
where id = 14;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/346940/header.jpg?t=1561555035"
where id = 15;

update games
set image="https://cdn02.nintendo-europe.com/media/images/10_share_images/games_15/nintendo_switch_download_software_1/H2x1_NSwitchDS_CaveStoryPlus_image1600w.jpg"
where id = 16;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/411000/header.jpg?t=1572348098"
where id = 17;

update games
set image="https://steamcdn-a.akamaihd.net/steam/apps/975370/header.jpg?t=1580248926"
where id = 18;
